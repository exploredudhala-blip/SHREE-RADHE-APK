plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.shreeradhe.water"
    compileSdk=35
    defaultConfig {
        applicationId="com.shreeradhe.water"
        minSdk=24
        targetSdk=35
        versionCode=5
        versionName="5.0"
    }
}
