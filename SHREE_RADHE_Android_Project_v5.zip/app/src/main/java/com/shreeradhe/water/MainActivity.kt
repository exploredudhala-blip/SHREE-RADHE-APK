package com.shreeradhe.water

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity:Activity(){
 private val p by lazy{getSharedPreferences("shree_radhe",0)}
 private var role="owner";private var full=1000;private var empty=0;private var orders=0;private var sales=0
 private val bills=mutableListOf<String>();private val deliveries=mutableListOf<String>()
 private lateinit var info:TextView

 private fun tv(s:String,n:Float=16f)=TextView(this).apply{text=s;textSize=n;setTextColor(Color.rgb(16,34,74));setPadding(12,10,12,10)}
 private fun bt(s:String,f:()->Unit)=Button(this).apply{text=s;setOnClickListener{f()}}
 override fun onCreate(b:Bundle?){super.onCreate(b);load();if(p.getBoolean("logged",false))home()else login()}
 private fun load(){
  role=p.getString("role","owner")?:"owner";full=p.getInt("full",1000);empty=p.getInt("empty",0);orders=p.getInt("orders",0);sales=p.getInt("sales",0)
  bills.clear();val a=JSONArray(p.getString("bills","[]")?:"[]");for(i in 0 until a.length())bills.add(a.getString(i))
  deliveries.clear();val d=JSONArray(p.getString("deliveries","[]")?:"[]");for(i in 0 until d.length())deliveries.add(d.getString(i))
 }
 private fun save(){
  val a=JSONArray();bills.forEach{a.put(it)};val d=JSONArray();deliveries.forEach{d.put(it)}
  p.edit().putBoolean("logged",true).putString("role",role).putInt("full",full).putInt("empty",empty).putInt("orders",orders).putInt("sales",sales).putString("bills",a.toString()).putString("deliveries",d.toString()).apply()
 }
 private fun login(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,30,24,20)}
  box.addView(tv("💧 SHREE RADHE\nShuddha Shital Jal",26f));box.addView(tv("Secure Owner / Delivery Boy Login",20f))
  val user=EditText(this);user.hint="Owner or Delivery Boy";box.addView(user)
  val pin=EditText(this);pin.hint="PIN (demo validation)";pin.inputType=2;box.addView(pin)
  box.addView(bt("🔐 Login"){
   if(user.text.toString().trim().isEmpty()||pin.text.toString().length<4)Toast.makeText(this,"Name आणि 4-digit PIN भरा",Toast.LENGTH_SHORT).show()
   else{role=if(user.text.toString().lowercase().contains("delivery"))"delivery" else "owner";save();home()}
  });setContentView(box)
 }
 private fun home(){
  val sc=ScrollView(this);val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,12,16,24)}
  box.addView(tv("💧 SHREE RADHE\nShuddha Shital Jal",25f));box.addView(tv(if(role=="owner")"👨‍💼 Owner Dashboard" else "🚚 Delivery Boy Dashboard",20f))
  info=tv("");box.addView(info);refresh()
  if(role=="owner"){
   box.addView(tv("Owner Controls",19f));box.addView(bt("🧾 New Customer Bill"){bill()})
   box.addView(bt("👥 Customer / Bill History"){history()});box.addView(bt("📦 Edit Full Stock"){edit(true)});box.addView(bt("🔄 Edit Empty Stock"){edit(false)})
   box.addView(bt("🚚 Assign Delivery"){assignDelivery()});box.addView(bt("📊 Reports"){report()});box.addView(bt("☁️ Cloud Setup Info"){cloudInfo()})
  }else{
   box.addView(tv("Assigned Deliveries",19f));box.addView(bt("📋 View Assigned Orders"){history()})
   box.addView(bt("✅ Complete Delivery"){completeDelivery()})
  }
  box.addView(bt("🔐 Logout"){p.edit().putBoolean("logged",false).apply();login()});sc.addView(box);setContentView(sc)
 }
 private fun refresh(){info.text="📦 Full: $full   🔄 Empty: $empty\n🧾 Orders: $orders   💰 Sales: ₹$sales\n🚚 Assigned: ${deliveries.size}"}
 private fun edit(isFull:Boolean){
  val e=EditText(this);e.inputType=2;e.hint="Stock"
  AlertDialog.Builder(this).setTitle(if(isFull)"Edit Full Stock" else "Edit Empty Stock").setView(e)
   .setPositiveButton("Save"){_,_->e.text.toString().toIntOrNull()?.let{if(it>=0){if(isFull)full=it else empty=it;save();refresh()}}}.setNegativeButton("Cancel",null).show()
 }
 private fun bill(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,8,18,8)}
  val name=EditText(this);name.hint="Customer name";box.addView(name);val mobile=EditText(this);mobile.hint="Mobile";box.addView(mobile)
  val qty=EditText(this);qty.hint="20L cans";qty.inputType=2;box.addView(qty);val paid=EditText(this);paid.hint="Paid";paid.inputType=2;box.addView(paid)
  AlertDialog.Builder(this).setTitle("🧾 Bill • ₹30 / 20L").setView(box).setPositiveButton("Create"){_,_->
   val q=qty.text.toString().toIntOrNull()?:0;if(q<=0||q>full){Toast.makeText(this,"Quantity/stock तपासा",Toast.LENGTH_SHORT).show();return@setPositiveButton}
   val total=q*30;val pay=(paid.text.toString().toIntOrNull()?:0).coerceIn(0,total);val due=total-pay
   full-=q;empty+=q;orders++;sales+=total
   bills.add("${name.text}|${mobile.text}|$q cans|₹$total|Paid ₹$pay|Due ₹$due|Pending")
   save();refresh();Toast.makeText(this,"Bill ₹$total • बाकी ₹$due",Toast.LENGTH_LONG).show()
  }.setNegativeButton("Cancel",null).show()
 }
 private fun history(){AlertDialog.Builder(this).setTitle("👥 Customer / Delivery History").setMessage(if(bills.isEmpty())"No bills yet." else bills.joinToString("\n\n")).setPositiveButton("OK",null).show()}
 private fun report(){AlertDialog.Builder(this).setTitle("📊 Reports").setMessage("Orders: $orders\nSales: ₹$sales\nFull stock: $full\nEmpty stock: $empty\nDeliveries: ${deliveries.size}").setPositiveButton("OK",null).show()}
 private fun assignDelivery(){
  if(bills.isEmpty()){Toast.makeText(this,"पहिले bill/order तयार करा",Toast.LENGTH_SHORT).show();return}
  val items=bills.toTypedArray()
  AlertDialog.Builder(this).setTitle("🚚 Assign latest order").setItems(items){_,which->
   deliveries.add("ASSIGNED • ${items[which]}");save();refresh();Toast.makeText(this,"Delivery assigned.",Toast.LENGTH_SHORT).show()
  }.show()
 }
 private fun completeDelivery(){
  if(deliveries.isEmpty()){Toast.makeText(this,"Assigned delivery नाही",Toast.LENGTH_SHORT).show();return}
  val items=deliveries.toTypedArray()
  AlertDialog.Builder(this).setTitle("Complete Delivery").setItems(items){_,which->
   deliveries[which]=deliveries[which].replace("ASSIGNED","DELIVERED");save();refresh();Toast.makeText(this,"Delivery completed.",Toast.LENGTH_SHORT).show()
  }.show()
 }
 private fun cloudInfo(){
  AlertDialog.Builder(this).setTitle("☁️ Cloud Database")
   .setMessage("Cloud sync architecture is ready to connect. A real Firebase/other cloud project must be created and its credentials/config added before automatic online backup can work. This version safely keeps local data and supports the earlier backup-file feature.")
   .setPositiveButton("OK",null).show()
 }
}
